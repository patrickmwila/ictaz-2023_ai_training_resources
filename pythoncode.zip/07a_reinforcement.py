import numpy as np

# True probabilities of success for each bandit
p_bandits = [0.45, 0.40, 0.80]

# Number of bandits
num_bandits = len(p_bandits)

# Epsilon value for exploration
epsilon = 0.1

def choose_bandit(p_bandits, epsilon):
    if np.random.random() < epsilon:
        # Explore: choose a random bandit
        chosen_bandit = np.random.choice(num_bandits)
    else:
        # Exploit: choose the bandit with the highest estimated probability
        chosen_bandit = np.argmax(p_bandits)
    return chosen_bandit

def pull_bandit(bandit):
    # Simulate pulling a bandit arm and getting a reward
    if np.random.random() < p_bandits[bandit]:
        return 1  # Success
    else:
        return 0  # Failure

# Initialize action values and action counts
Q = np.zeros(num_bandits)
N = np.zeros(num_bandits)

# Number of total steps
num_steps = 1000

# Store rewards for each step
rewards = []

for step in range(num_steps):
    chosen_bandit = choose_bandit(Q, epsilon)
    reward = pull_bandit(chosen_bandit)
    
    # Update action count
    N[chosen_bandit] += 1
    
    # Update action value using sample-average method
    Q[chosen_bandit] += (reward - Q[chosen_bandit]) / N[chosen_bandit]
    
    rewards.append(reward)

# Print the estimated action values for each bandit
for i, q in enumerate(Q):
    print(f"Estimated value for bandit {i+1}: {q:.3f}")

# Print the total reward obtained
print(f"Total reward obtained: {sum(rewards)}")

