import warnings
warnings.filterwarnings("ignore")

import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score

# Given data
x = [4, 5, 10, 4, 3, 11, 14, 6, 10, 12]
y = [21, 19, 24, 17, 16, 25, 24, 22, 21, 21]

# Combine the features into a single array
data = np.array(list(zip(x, y)))

# Apply Agglomerative clustering
n_clusters = 3
agglomerative = AgglomerativeClustering(n_clusters=n_clusters)
labels = agglomerative.fit_predict(data)

# Calculate performance metrics
silhouette_avg = silhouette_score(data, labels)
davies_bouldin = davies_bouldin_score(data, labels)
calinski_harabasz = calinski_harabasz_score(data, labels)

print("Silhouette Score:", silhouette_avg)
print("Davies-Bouldin Index:", davies_bouldin)
print("Calinski-Harabasz Index:", calinski_harabasz)

# Plot the data and cluster assignments
plt.scatter(data[:, 0], data[:, 1], c=labels, cmap='viridis')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Agglomerative Clustering')
plt.show()
