import warnings
warnings.filterwarnings("ignore")

#The elbow method involves plotting the sum of squared distances (inertia) for a range of cluster numbers. As you increase the number of clusters, the inertia tends to decrease, because each point is closer to its own cluster's centroid. However, beyond a certain point, adding more clusters doesn't provide much reduction in inertia. The "elbow point" on the plot is a good candidate for the optimal number of clusters.
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

x = [4, 5, 10, 4, 3, 11, 14, 6, 10, 12]
y = [21, 19, 24, 17, 16, 25, 24, 22, 21, 21]
data = np.array(list(zip(x, y)))

inertia_values = []
for n_clusters in range(1, 11):
    kmeans = KMeans(n_clusters=n_clusters)
    kmeans.fit(data)
    inertia_values.append(kmeans.inertia_)

plt.plot(range(1, 11), inertia_values, marker='o')
plt.xlabel('Number of Clusters')
plt.ylabel('Inertia')
plt.title('Elbow Method for Optimal Clusters')
plt.show()

'''
# to calculate knee see https://github.com/arvkevi/kneed
from kneed import KneeLocator
kneedle = KneeLocator(x, y, S=1.0, curve="convex", direction="decreasing")
print(round(kneedle.knee, 3))

'''

import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# Given data
x = [4, 5, 10, 4, 3, 11, 14, 6, 10, 12]
y = [21, 19, 24, 17, 16, 25, 24, 22, 21, 21]

# Combine the features into a single array
data = np.array(list(zip(x, y)))
print(data)

# this is the data
plt.scatter(x, y)
plt.title('This is original data')
plt.show()

# Apply K-means clustering
n_clusters = 3
n_init='auto'
kmeans = KMeans(n_clusters=n_clusters)
kmeans.fit(data)
labels = kmeans.labels_
centers = kmeans.cluster_centers_

# Plot the data and cluster centers
plt.scatter(x, y, c=kmeans.labels_)
plt.scatter(centers[:, 0], centers[:, 1], c='red', marker='X', s=200)
plt.xlabel('X')
plt.ylabel('Y')
plt.title('K-means Clustering')
plt.show()

#Inertia measures the sum of squared distances between each data point
inertia = kmeans.inertia_
print("Inertia:", inertia)

# silhouette score measures how close each data point in one cluster is to the points in the neighboring clusters. A higher silhouette score indicates better-defined clusters.
from sklearn.metrics import silhouette_score

silhouette_avg = silhouette_score(data, labels)
print("Silhouette Score:", silhouette_avg)

#Davies-Bouldin Index: This index measures the average similarity between each cluster and its most similar cluster. Lower values indicate better clustering
from sklearn.metrics import davies_bouldin_score

davies_bouldin = davies_bouldin_score(data, labels)
print("Davies-Bouldin Index:", davies_bouldin)

#Calinski-Harabasz Index (Variance Ratio Criterion): This index measures the ratio of between-cluster variance to within-cluster variance. Higher values indicate better-defined clusters.
from sklearn.metrics import calinski_harabasz_score

calinski_harabasz = calinski_harabasz_score(data, labels)
print("Calinski-Harabasz Index:", calinski_harabasz)


