import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, log_loss, confusion_matrix, roc_auc_score, f1_score, mean_absolute_error, mean_squared_error
from sklearn.preprocessing import StandardScaler

# Load the diabetes dataset
data = load_diabetes()
X = data.data
y = (data.target > 150).astype(int)  # Convert to binary classification problem

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Initialize classifiers
classifiers = {
    "Decision Tree": DecisionTreeClassifier(),
    "Naive Bayes": GaussianNB(),
    "SVM": SVC(probability=True),
    "KNN": KNeighborsClassifier()
}

# Initialize metrics
metrics = {
    "Classification Accuracy": accuracy_score,
    "Logarithmic Loss": log_loss,
    "Confusion Matrix": confusion_matrix,
    "Area under Curve": roc_auc_score,
    "F1 Score": f1_score,
    "Mean Absolute Error": mean_absolute_error,
    "Mean Squared Error": mean_squared_error
}

# Iterate over classifiers
for name, clf in classifiers.items():
    print(f"Classifier: {name}")
    clf.fit(X_train, y_train)
    
    # Predict probabilities for Log Loss and AUC
    if name in ["Decision Tree", "KNN"]:
        y_pred_prob = clf.predict_proba(X_test)[:, 1]
    else:
        y_pred_prob = clf.predict_proba(X_test)[:, 1]
    
    # Iterate over metrics
    for metric_name, metric_func in metrics.items():
        if metric_name == "Confusion Matrix":
            print(f"{metric_name}:\n{metric_func(y_test, clf.predict(X_test))}")
        else:
            print(f"{metric_name}: {metric_func(y_test, y_pred_prob if 'AUC' in metric_name else clf.predict(X_test)):.4f}")
    
    print("="*50)

# note that some classifiers (e.g., Decision Tree and KNN) don't have built-in predict probabilities, so we use predict_proba for consistent metric calculation. SVM and Naive Bayes classifiers have probabilistic outputs.

