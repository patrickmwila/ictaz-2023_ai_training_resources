from sklearn import datasets

data = datasets.load_breast_cancer()

print(data.keys())
# print(data.DESCR)

# print(list(data.target_names))
# print(list(data.data))

print(data.target_names)

# thеy аrе mаppеd tо binаry vаluеs 0 аnd 1
print(data.target[0])

print("This is the data",data.data)

from sklearn.model_selection import train_test_split

X = data.data # Features
y = data.target # Target variable

# Split dataset into training set and test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1) # 70% training and 30% test

from sklearn.naive_bayes import GaussianNB

gnb = GaussianNB()

mоdеl = gnb.fit(X_train,y_train)

y_pred = gnb.predict(X_test) 

print("This is the prediction",y_pred)

from sklearn import metrics  
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))

