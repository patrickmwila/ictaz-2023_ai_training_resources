import numpy as np
import pandas as pd
from sklearn import linear_model
import statsmodels.api as sm
import matplotlib.pyplot as plt

data = pd.read_csv('Salary_Data.csv')
x = data['YearsExperience']
y = data['Salary']

df = pd.DataFrame(data)
print(df)

# with statsmodels
x = sm.add_constant(x) # adding a constant
 
model = sm.OLS(y, x).fit()
predictions = model.predict(x) 

print_model = model.summary()
print(print_model)

plt.scatter(df['YearsExperience'], df['Salary'], color='green')
plt.title('Salary Vs YearsExperience', fontsize=14)
plt.xlabel('YearsExperience', fontsize=14)
plt.ylabel('Salary', fontsize=14)
plt.grid(True)
plt.show()
