import numpy as np
from sklearn.covariance import EllipticEnvelope, MinCovDet
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from sklearn.neighbors import LocalOutlierFactor
from sklearn.metrics import confusion_matrix

# Given age data
ages = [11, 20, 20, 20, 21, 21, 22, 22, 23, 24, 24, 25, 25, 25, 25, 28, 30, 33, 33, 35, 35, 35, 35, 36, 40, 45, 46, 52, 66, 64, 62, 80]

# Reshape the data to a 2D array
X = np.array(ages).reshape(-1, 1)

# Algorithms for outlier detection with adjusted hyperparameters
algorithms = {
    "Elliptic Envelope": EllipticEnvelope(contamination=0.05),
    "Isolation Forest": IsolationForest(contamination=0.05, random_state=42),
    "One-class SVM": OneClassSVM(nu=0.05),
    "Local Outlier Factor": LocalOutlierFactor(n_neighbors=20, contamination=0.05)
}

# Evaluate each algorithm
for name, algorithm in algorithms.items():
    if name == "Local Outlier Factor":
        y_pred = algorithm.fit_predict(X)
    else:
        y_pred = algorithm.fit(X).predict(X)
    
    # Convert -1 (outliers) to 1, and 1 (inliers) to 0 for comparison with ground truth
    y_pred[y_pred == -1] = 1
    y_pred[y_pred == 1] = 0
    
    # Evaluate performance
    confusion_mat = confusion_matrix(np.ones(len(X)), y_pred)
    tn, fp, fn, tp = confusion_mat.ravel()
    
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    
    # Handle division by zero for precision
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    
    recall = tp / (tp + fn)
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
    
    print(f"Algorithm: {name}")
    print("Confusion Matrix:\n", confusion_mat)
    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall:", recall)
    print("F1 Score:", f1)
    print("=" * 50)
