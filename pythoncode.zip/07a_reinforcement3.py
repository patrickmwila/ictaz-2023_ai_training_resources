#Step 1: Importing the required libraries
import numpy as np
import pylab as pl
import matplotlib.pyplot as plt
import networkx as nx

#Step 2: Defining and visualising the graph
edges = [(0, 1), (1, 5), (5, 6), (5, 4), (1, 2),
(1, 3), (9, 10), (2, 4), (0, 6), (6, 7),
(8, 9), (7, 8), (1, 7), (3, 9)]

goal = 10
G = nx.Graph()
G.add_edges_from(edges)
pos = nx.spring_layout(G)
nx.draw_networkx_nodes(G, pos)
nx.draw_networkx_edges(G, pos)
nx.draw_networkx_labels(G, pos)
pl.show()

# Step 3: Defining the reward the system for the bot

MATRIX_SIZE = 11
M = np.matrix(np.ones(shape =(MATRIX_SIZE, MATRIX_SIZE)))
M *= -1

for point in edges:
	print(point)
	if point[1] == goal:
		M[point] = 100
else:
	M[point] = 0

if point[0] == goal:
	M[point[::-1]] = 100
else:
	M[point[::-1]]= 0
# reverse of point

M[goal, goal]= 100
print(M)


# Step 4: Defining some utility functions to be used in the training
# Define the Q-learning parameters
gamma = 0.8  # Discount factor
alpha = 0.1  # Learning rate

# Define the Q-matrix size
MATRIX_SIZE = 11

# Initialize the Q-matrix with zeros
Q = np.matrix(np.zeros(shape=(MATRIX_SIZE, MATRIX_SIZE)))

# Define the reward matrix
R=M
'''
R = np.matrix(np.array([
    [-1, -1, -1, -1,  0,  -1],
    [-1, -1, -1,  0, -1, 100],
    [-1, -1, -1,  0, -1,  -1],
    [-1,  0,  0, -1,  0,  -1],
    [ 0, -1, -1,  0, -1, 100],
    [-1,  0, -1, -1,  0, 100]
]))
'''

def choose_action(state):
    # Choose an action based on the current state using epsilon-greedy
    if np.random.uniform(0, 1) < 0.5:
        return np.random.choice(MATRIX_SIZE)
    else:
        return np.argmax(Q[state, :])

def update_q_matrix(state, action, next_state):
    # Update the Q-matrix using the Q-learning formula
    max_value = np.max(Q[next_state, :])
    Q[state, action] = (1 - alpha) * Q[state, action] + alpha * (R[state, action] + gamma * max_value)

def train_q_learning(num_episodes):
    for _ in range(num_episodes):
        state = np.random.randint(0, MATRIX_SIZE)
        while state != 5:
            action = choose_action(state)
            next_state = action
            update_q_matrix(state, action, next_state)
            state = next_state

def evaluate_q_learning(start_state, max_steps):
    state = start_state
    steps = 0
    print("Agent's path:")
    while state != 5 and steps < max_steps:
        action = choose_action(state)
        print(state, end=' -> ')
        state = action
        steps += 1
    print(state)

# Train the Q-learning agent
train_q_learning(num_episodes=1000)

# Evaluate the trained agent
start_state = 2
max_steps = 10
evaluate_q_learning(start_state, max_steps)

def train_q_learning(num_episodes):
    rewards_per_episode = []
    for _ in range(num_episodes):
        state = np.random.randint(0, MATRIX_SIZE)
        total_reward = 0
        while state != 5:
            action = choose_action(state)
            next_state = action
            total_reward += R[state, action]
            update_q_matrix(state, action, next_state)
            state = next_state
        rewards_per_episode.append(total_reward)
    return rewards_per_episode

# Train the Q-learning agent and collect rewards per episode
num_episodes = 1000
rewards_per_episode = train_q_learning(num_episodes)

# Plot the number of iterations against the reward gained
plt.plot(range(num_episodes), rewards_per_episode)
plt.xlabel('Episode')
plt.ylabel('Total Reward')
plt.title('Number of Iterations vs Reward Gained')
plt.show()

# Evaluate the trained agent
start_state = 2
max_steps = 10
evaluate_q_learning(start_state, max_steps)

#Step 6: Defining and visualizing the new graph with the environmental clues

goal = 10
police = [2, 4, 5]
drug_traces = [3, 8, 9]

G = nx.Graph()
G.add_edges_from(edges)

mapping = {0: '0 - Detective', 1: '1', 2: '2 - Police', 3: '3 - Drug traces',
           4: '4 - Police', 5: '5 - Police', 6: '6', 7: '7', 8: '8 - Drug traces',
           9: '9 - Drug traces', 10: '10 - Drug racket location'}

H = nx.relabel_nodes(G, mapping)
pos = nx.spring_layout(H)

# Draw nodes
node_sizes = [200 if node in police or node in drug_traces else 100 for node in H.nodes()]
nx.draw_networkx_nodes(H, pos, node_size=node_sizes)

# Draw edges and labels
nx.draw_networkx_edges(H, pos)
nx.draw_networkx_labels(H, pos)
pl.show()
