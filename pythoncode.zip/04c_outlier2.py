import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.covariance import EllipticEnvelope, MinCovDet
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from sklearn.neighbors import LocalOutlierFactor
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score

# Load the dataset
data_url = "banknotes.csv"
df = pd.read_csv(data_url)

# Display the dataset
print("Dataset:")
print(df.head())

# Separate features and labels
X = df.drop(columns=['conterfeit'])
y_true = df['conterfeit']

# Boxplot of features
plt.figure(figsize=(10, 6))
X.boxplot()
plt.title("Boxplot of Features")
plt.xticks(rotation=45)
plt.show()
'''
# Scatterplot of features
plt.figure(figsize=(10, 6))
plt.scatter(X['notelength'], X['noteheight'], c=y_true, cmap='viridis')
plt.xlabel('Length')
plt.ylabel('Height')
plt.title('Scatterplot of Features')
plt.show()
'''
# Algorithms for outlier detection with adjusted hyperparameters
algorithms = {
    "Elliptic Envelope": EllipticEnvelope(contamination=0.05),
    "Isolation Forest": IsolationForest(contamination=0.05, random_state=42),
    "One-class SVM": OneClassSVM(nu=0.05),
    "Local Outlier Factor": LocalOutlierFactor(n_neighbors=20, contamination=0.05),
}

# Evaluate each algorithm
for name, algorithm in algorithms.items():
    if name == "Local Outlier Factor":
        y_scores = -algorithm.fit_predict(X)
    else:
        y_scores = -algorithm.fit(X).decision_function(X)

    # Calculate performance metrics
    auc_roc = roc_auc_score(y_true, y_scores)
    auc_pr = average_precision_score(y_true, y_scores)
    f1 = f1_score(y_true, (y_scores > 0).astype(int))

    print(f"Algorithm: {name}")
    print("AUC-ROC:", auc_roc)
    print("AUC-PR:", auc_pr)
    print("F1 Score:", f1)
    print("=" * 50)
