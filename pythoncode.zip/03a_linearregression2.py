import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Example data
interest_rates = np.array([1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0])
index_prices = np.array([2500, 2700, 3000, 3200, 3500, 3800, 4000, 4200, 4500, 4800])

# Reshape the data to fit the scikit-learn API
interest_rates = interest_rates.reshape(-1, 1)

# Initialize the Linear Regression model
model = LinearRegression()

# Fit the model to the data
model.fit(interest_rates, index_prices)

# Get the intercept and coefficient
intercept = model.intercept_
coefficient = model.coef_[0]

# Generate points along the regression line for plotting
regression_line = model.predict(interest_rates)

# Plot the data points and the regression line
plt.figure(figsize=(10, 6))
plt.scatter(interest_rates, index_prices, color='blue', label='Data Points')
plt.plot(interest_rates, regression_line, color='red', label='Regression Line')
plt.xlabel('Interest Rate')
plt.ylabel('Index Price')
plt.title('Linear Regression: Index Price vs. Interest Rate')
plt.legend()
plt.grid(True)
plt.show()

print(f"Intercept: {intercept:.2f}")
print(f"Coefficient: {coefficient:.2f}")

