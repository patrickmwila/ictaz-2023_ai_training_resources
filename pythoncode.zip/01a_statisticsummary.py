"""
Created on Fri Jan 31 15:27:02 2020

Demo purposes using scipy
"""
import numpy 
from scipy import stats
import matplotlib.pyplot as plt
#

ages=[11, 20, 20, 20, 21, 21, 22, 22, 23, 24, 24, 25, 25, 25, 25, 28, 30, 33, 33, 35, 35, 35, 35, 36, 40, 45, 46, 52, 66, 64, 62, 80]

#(a) What is the mean  of the data? What is the median ?

print("Age Values: ",ages)
#Compute mean
ageMean = numpy.mean(ages)
print("Age Mean =",ageMean)
  
#Compute median
ageMedian = numpy.median(ages)
print("Age Median =",ageMedian)

#(b) What is the mode  of the data? Comment on the data’s modality (i.e., bimodal, trimodal, etc.).
#Compute mode
ageMode = stats.mode(ages)
print("Age Mode =",ageMode)

#(c) What is the midrange  of the data?

#compute midRange MidRange = (max + min) / 2
ageMax = numpy.max(ages)
ageMin = numpy.min(ages)
ageMidRange=(ageMax+ageMin)/2
print("Age MidRange =",ageMidRange)

#(d) Can you find (roughly) the first quartile (Q1 ) and the third quartile (Q3 ) of the data?
print("Q1 quantile of age = ", numpy.quantile(ages, .25)) 
print("Q3 quantile of age = ", numpy.quantile(ages, .75)) 

#(e) Give the five-number summary  of the data.
 #= 1, Q1 = 5, median = 9, Q3 = 18, and maximum = 27.
print("five-number summary : ","Minimum =",ageMin," , Q1 =",numpy.quantile(ages, .25),", Median =", 
ageMedian," Q3 = ",numpy.quantile(ages, .75), " Maximum =",ageMax)

# Creating boxplot for dataset 
fig = plt.figure(figsize =(10, 7)) 
plt.boxplot(ages) 
  
# show plot for dataset
plt.show()



