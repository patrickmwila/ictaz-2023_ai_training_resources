from transformers import pipeline

# Load sentiment analysis pipeline
classifier = pipeline('sentiment-analysis')

# Example texts
texts = [
    "I love this product, it's amazing!",
    "This movie was terrible, I hated it.",
    "The weather is nice today.",
    "I'm not sure how I feel about this."
]

# Perform sentiment analysis
results = classifier(texts)

# Print results
for text, result in zip(texts, results):
    sentiment = result['label']
    confidence = result['score']
    print(f"Text: {text}\nSentiment: {sentiment}\nConfidence: {confidence:.2f}\n")
