import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Load data from CSV file
data = pd.read_csv('Salary_Data.csv')
print(data)
# Extract interest rates and index prices columns from the DataFrame
YearsExperience = data['YearsExperience'].values
Salary = data['Salary'].values

# Reshape the data to fit the scikit-learn API
YearsExperience = YearsExperience.reshape(-1, 1)

# Initialize the Linear Regression model
model = LinearRegression()

# Fit the model to the data
model.fit(YearsExperience, Salary)

# Get the intercept and coefficient
intercept = model.intercept_
coefficient = model.coef_[0]
print(f"Intercept: {intercept:.2f}")
print(f"Coefficient: {coefficient:.2f}")

# Generate points along the regression line for plotting
regression_line = model.predict(YearsExperience)

# Plot the data points and the regression line
plt.figure(figsize=(10, 6))
plt.scatter(YearsExperience, Salary, color='blue', label='Data Points')
plt.plot(YearsExperience, regression_line, color='red', label='Regression Line')
plt.xlabel('Years of Experience')
plt.ylabel('Salary')
plt.title('Linear Regression: Salry vs. Years of Experience')
plt.legend()
plt.grid(True)
plt.show()


