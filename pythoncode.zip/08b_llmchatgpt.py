import openai

# Set your OpenAI API key here
api_key = "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"

# Initialize the OpenAI API client
openai.api_key = api_key

# Prompt the user for a question
user_question = input("Ask a question: ")

# Compose the prompt for the API call
prompt = f"Question: {user_question}\nAnswer:"

# Make the API call to generate an answer
response = openai.Completion.create(
    engine="davinci",  # You can choose different engines, e.g., "davinci-codex" for code generation
    prompt=prompt,
    max_tokens=50  # Adjust as needed for desired answer length
)

# Extract and print the answer
answer = response.choices[0].text.strip()
print("Answer:", answer)

'''
import openai
openai.api_key = "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"
model_engine = "gpt-3.5-turbo" 
# This specifies which GPT model to use, as there are several models available

response = openai.ChatCompletion.create(
    model='gpt-3.5-turbo',
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello, ChatGPT!"},
    ])

message = response.choices[0]['message']
print("{}: {}".format(message['role'], message['content']))
'''
