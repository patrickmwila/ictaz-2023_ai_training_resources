import numpy as np
import gym

# Create the Taxi-v3 environment
env = gym.make("Taxi-v3")

# Q-learning parameters
num_episodes = 1000
max_steps_per_episode = 200
learning_rate = 0.8
discount_factor = 0.95
exploration_prob = 0.2

# Initialize Q-table with zeros
num_states = env.observation_space.n
num_actions = env.action_space.n
q_table = np.zeros((num_states, num_actions))

# Q-learning algorithm
for episode in range(num_episodes):
    state = env.reset()
    done = False
    
    for step in range(max_steps_per_episode):
        # Exploration vs. exploitation
        if np.random.uniform(0, 1) < exploration_prob:
            action = env.action_space.sample()  # Choose a random action
        else:
            action = np.argmax(q_table[state, :])  # Choose the action with max Q-value
        
        next_state, reward, done, _ = env.step(action)
        
        # Update Q-value using the Bellman equation
        q_table[state, action] = (1 - learning_rate) * q_table[state, action] + \
                                 learning_rate * (reward + discount_factor * np.max(q_table[next_state, :]))
        
        state = next_state
        
        if done:
            break

# Evaluate the learned policy
num_episodes_eval = 100
total_rewards = 0

for episode in range(num_episodes_eval):
    state = env.reset()
    done = False
    
    while not done:
        action = np.argmax(q_table[state])  # Choose the action with max Q-value
        next_state, reward, done, _ = env.step(action)
        total_rewards += reward
        state = next_state

average_reward = total_rewards / num_episodes_eval
print("Average reward:", average_reward)

'''
 action = np.argmax(q_table[state, :])  # Choose the action with max Q-value
                       ~~~~~~~^^^^^^^^^^
IndexError: only integers, slices (`:`), ellipsis (`...`), numpy.newaxis (`None`) and integer or boolean arrays are valid indices

'''
