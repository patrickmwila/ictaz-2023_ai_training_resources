import os
os.environ["OPENAI_API_KEY"] ="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"

from langchain.llms import OpenAI
llm = OpenAI(temperature=0.9) 

prompt = "Suggest me a good name for an ice cream parlour that is located on a beach!"
print(llm(prompt))


from langchain import OpenAI, ConversationChain

llm = OpenAI(temperature=0)
conversation = ConversationChain(llm=llm, verbose=True)

conversation.predict(input="Hi there!")
conversation.predict(input="Can we talk about AI?")
conversation.predict(input="I'm interested in Reinforcement Learning.")
