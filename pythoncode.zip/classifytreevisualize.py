# to demonstrate tree visualize
import pandas as pd
from matplotlib import pyplot as plt
from sklearn import datasets
from sklearn.tree import DecisionTreeClassifier 
from sklearn import tree

# Prepare the data data
iris = datasets.load_iris()
X = iris.data
y = iris.target

# Fit the classifier with default hyper-parameters
clf = DecisionTreeClassifier(random_state=1234)
model = clf.fit(X, y)

text_representation = tree.export_text(clf)
print(text_representation)

# to save to file uncomment next 2 lines
#with open("decistion_tree.log", "w") as fout:
#    fout.write(text_representation)

fig = plt.figure(figsize=(10,7)) # was 25,20
_ = tree.plot_tree(clf, 
                   feature_names=iris.feature_names,  
                   class_names=iris.target_names,
                   filled=True)
plt.show()

# to save to file uncomment next line
#fig.savefig("decistion_tree.png")

# source: https://mljar.com/blog/visualize-decision-tree/
'''
import pandas as pd
from termcolor import colored as cl # text customization
df = pd.read_csv('treetest.csv')
df.drop('ID', axis = 1, inplace = True)

print(cl(df.head(), attrs = ['bold']))
'''


