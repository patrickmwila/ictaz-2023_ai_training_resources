import numpy as np
import matplotlib.pyplot as plt
from sklearn.covariance import EllipticEnvelope, MinCovDet
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from sklearn.neighbors import LocalOutlierFactor
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score

# Generate a dataset with outliers
np.random.seed(0)
inliers = np.random.normal(20, 5, 200).reshape(-1, 1)
outliers = np.random.normal(60, 10, 10).reshape(-1, 1)
X = np.vstack((inliers, outliers))
print(X)

# True labels (0 for inliers, 1 for outliers)
y_true = np.zeros(len(X))
y_true[len(inliers):] = 1

# Algorithms for outlier detection with adjusted hyperparameters
algorithms = {
    "Elliptic Envelope": EllipticEnvelope(contamination=0.05),
    "Isolation Forest": IsolationForest(contamination=0.05, random_state=42),
    "One-class SVM": OneClassSVM(nu=0.05),
    "Local Outlier Factor": LocalOutlierFactor(n_neighbors=20, contamination=0.05)
}

# Visualize the data
plt.figure(figsize=(10, 6))
plt.scatter(X, y_true, c='gray', marker='o', label='Inliers')
plt.scatter(X[y_true == 1], y_true[y_true == 1], c='red', marker='x', label='Outliers')
plt.xlabel('Age')
plt.ylabel('Outlier Label')
plt.title('Outlier Detection Data')
plt.legend()
plt.show()

# Evaluate each algorithm
for name, algorithm in algorithms.items():
    if name == "Local Outlier Factor":
        y_scores = -algorithm.fit_predict(X)
    else:
        y_scores = -algorithm.fit(X).decision_function(X)
    
    # Calculate performance metrics
    auc_roc = roc_auc_score(y_true, y_scores)
    auc_pr = average_precision_score(y_true, y_scores)
    f1 = f1_score(y_true, (y_scores > 0).astype(int))
    
    print(f"Algorithm: {name}")
    print("AUC-ROC:", auc_roc)
    print("AUC-PR:", auc_pr)
    print("F1 Score:", f1)
    print("=" * 50)
