# read from file and ask Google Speech Recognition API
import speech_recognition as sr

# use audio file as input
r = sr.Recognizer()
with sr.AudioFile('english.wav') as source:
    audio = r.record(source)  # read the entire audio file

# recognize speech using Google Speech Recognition
try:
    print("Google Speech Recognition says " + r.recognize_google(audio))
except sr.UnknownValueError:
    print("Google Speech Recognition could not understand audio")
except sr.RequestError as e:
    print("Could not request results from Google Speech Recognition service; {0}".format(e))


import wave
import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

# use audio file as input
wav_file = 'english.wav'

frequency, audio = wavfile.read(wav_file)

print('nSignal shape:', audio.shape)
print('Signal Datatype:', audio.dtype)
print('Signal duration:', round(audio.shape[0] /
float(frequency), 2), 'seconds')

# Open the WAV file
with wave.open(wav_file, 'rb') as wav:
    # Get the number of frames (samples)
    num_frames = wav.getnframes()
    # Read the audio data as bytes
    audio_data = wav.readframes(num_frames)
    # Get the sample width (bytes per sample)
    sample_width = wav.getsampwidth()

    # Convert the bytes to a numpy array based on the sample width
    if sample_width == 2:
        audio_array = np.frombuffer(audio_data, dtype=np.int16)
    elif sample_width == 4:
        audio_array = np.frombuffer(audio_data, dtype=np.int32)
    else:
        raise ValueError("Unsupported sample width")

    # Get the frame rate (samples per second)
    frame_rate = wav.getframerate()

# Calculate the time values for the x-axis
time_values = np.arange(0, num_frames) / frame_rate

# Plot the audio waveform
plt.figure(figsize=(10, 6))
plt.plot(time_values, audio_array)
plt.title('Audio Waveform')
plt.xlabel('Time (seconds)')
plt.ylabel('Amplitude')
plt.show()



'''
#import library
import speech_recognition as sr

# Initialize recognizer class (for recognizing the speech)
r = sr.Recognizer()
                   
with sr.Microphone() as source:
    print("Speak:")                      
    audio = r.listen(source)   

# recoginize_() method will throw a request error if the API is unreachable, hence using exception handling
try:
     # using google speech recognition
    print("You said " + r.recognize_google(audio))
except sr.UnknownValueError:
    print("Could not understand audio")
except sr.RequestError as e:
    print("Could not request results; {0}".format(e))
'''
