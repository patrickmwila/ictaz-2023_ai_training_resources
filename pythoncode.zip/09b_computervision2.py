import cv2
import numpy as np

image1 = cv2.imread('pingeons.jpg')

if image1 is None:
    print("Error: Could not read the image.")
else:
    # Display the image
    cv2.imshow("Image", image1)
    cv2.waitKey(0)  # Wait for a key press
    cv2.destroyAllWindows()  # Close the window

cv2.imwrite('edges_Penguins.jpg',cv2.Canny(image1,200,300))
image2 = cv2.imread('edges_Penguins.jpg')

if image2 is None:
    print("Error: Could not read the image.")
else:
    # Display the image
    cv2.imshow("Image", image2)
    cv2.waitKey(0)  # Wait for a key press
    cv2.destroyAllWindows()  # Close the window

image3 = cv2.cvtColor(image1,cv2.COLOR_BGR2GRAY)
if image3 is None:
    print("Error: Could not read the image.")
else:
    # Display the image
    cv2.imshow("Image", image3)
    cv2.waitKey(0)  # Wait for a key press
    cv2.destroyAllWindows()  # Close the window
